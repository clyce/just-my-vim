# Aligement.vim

Auto align the starting position of lines or the `=` position


`<Leader>[` to align the starting position

`<Leader>=` to align the `=` position

`<Leader>` default is `\`


![vim-alignment-show](http://i1297.photobucket.com/albums/ag23/yueyoum/vim-alignment_zps97cb7b5b.gif)


## install

using [vundle](https://github.com/gmarik/vundle)

or [pathogen](https://github.com/tpope/vim-pathogen)

